package Ayudantia_n3_26_09_2023.Listas;

public class ListaHuesped {
}
