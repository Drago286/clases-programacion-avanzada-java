package Ayudantia_n3_26_09_2023.Objetos;

import Ayudantia_n3_26_09_2023.Listas.ListaHuesped;

public class Casa {
    private int numero;
    private ListaHuesped listaHuespedes;

    public Casa(int numero, ListaHuesped listaHuespedes) {
        this.numero = numero;
        this.listaHuespedes = listaHuespedes;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public ListaHuesped getListaHuespedes() {
        return listaHuespedes;
    }

    public void setListaHuespedes(ListaHuesped listaHuespedes) {
        this.listaHuespedes = listaHuespedes;
    }
}
