package Ayudantia_n3_26_09_2023.Objetos;

public class Huesped {

}
