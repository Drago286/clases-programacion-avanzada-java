package Ayudantia_n2_05_09_2023;

import edu.princeton.cs.stdlib.StdIn;
import edu.princeton.cs.stdlib.StdOut;

public class Veterinaria {
    private String direccion;
    private Mascota[] listaMascota;
    private int capacidadMax;
    private int cantidadActual;

    public Veterinaria(String direccion, int capacidadMax) {
        this.direccion = direccion;
        this.capacidadMax = capacidadMax;
        this.cantidadActual = 0;
        this.listaMascota = new Mascota[this.capacidadMax];
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Mascota[] getListaMascota() {
        return listaMascota;
    }

    public void setListaMascota(Mascota[] listaMascota) {
        this.listaMascota = listaMascota;
    }

    public int getCapacidadMax() {
        return capacidadMax;
    }

    public void setCapacidadMax(int capacidadMax) {
        this.capacidadMax = capacidadMax;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public void setCantidadActual(int cantidadActual) {
        this.cantidadActual = cantidadActual;
    }

    public void atenderMascota() {
        StdOut.println("¿Nombre del dueño?");
        String nombreDuenio = isString();

        StdOut.println("¿Edad del dueño?");
        int edadDuenio = isInt();

        Duenio nuevoDuenio = new Duenio(edadDuenio, nombreDuenio);

        StdOut.println("¿Nombre de la mascota?");
        String nombreMascota = isString();

        StdOut.println("¿Edad de la mascota?");
        int edadMascota = isInt();

        StdOut.println("¿Especie de la mascota?");
        String especie = isString();

        Mascota nuevaMascota = new Mascota(nombreMascota, edadMascota, especie, nuevoDuenio);

        this.listaMascota[cantidadActual] = nuevaMascota;
        this.cantidadActual++;
    }

    public void listarMascotas() {
        if (this.cantidadActual > 0) {
            for (int i = 0; i < this.capacidadMax; i++) {
                if (this.listaMascota[i] != null) {
                    StdOut.println("Nombre: " + this.listaMascota[i].getNombre());
                    StdOut.println("Edad: " + this.listaMascota[i].getEdad());
                    StdOut.println("Especie: " + this.listaMascota[i].getEspecie());
                    if (this.listaMascota[i].isAlta()) {
                        StdOut.println("Mascota dada de alta");
                    } else {
                        StdOut.println("Mascota no dada de alta");
                    }
                    StdOut.println("-------------------");
                }
            }
        } else {
            StdOut.println("No hay mascotas en el sistema");
        }
    }

    public void darAlta() {
        if (this.cantidadActual > 0) {
            StdOut.println("Indique el nombre de la mascota:");
            String mascotaBuscada = isString();

            if (buscarMascota(mascotaBuscada)) {
                for (int i = 0; i < this.capacidadMax; i++) {
                    if (this.listaMascota[i] != null) {
                        if (this.listaMascota[i].getNombre().equals(mascotaBuscada)) {
                            this.listaMascota[i].setAlta(true);
                            break;
                        }
                    }
                }
            } else {
                StdOut.println("Mascota no encontrada");
            }
        } else {
            StdOut.println("No hay mascotas en el sistema");
        }
    }

    public boolean buscarMascota(String nombreBuscado) {
        if (this.cantidadActual > 0) {
            for (int i = 0; i < this.capacidadMax; i++) {
                if (this.listaMascota[i] != null) {
                    if (this.listaMascota[i].getNombre().equals(nombreBuscado)) {
                        return true;
                    }
                }
            }
        } else {
            return false;
        }
        return false;
    }

    public void informeDeSalida() {
        StdOut.println("----Hay  " + this.cantidadActual + "mascota(s) registradas en el sistema----");
        int cantAlta = 0;
        int cantNoAlta = 0;

        for (int i = 0; i < this.capacidadMax; i++) {
            if (this.listaMascota[i] != null) {
                if (this.listaMascota[i].isAlta()) {
                    cantAlta++;
                } else {
                    cantNoAlta++;
                }
            }
        }
        StdOut.println("Hay " + cantAlta + " mascotas dadas de alta.");
        StdOut.println("Hay " + cantNoAlta + " mascotas no dadas de alta.");

        StdOut.println("----Lista de mascotas atendidas----");
        listarMascotas();

        StdOut.println("Dueños del día:");
        for (int i = 0; i < this.capacidadMax; i++) {
            if (this.listaMascota[i] != null) {
                StdOut.println("Nombre del dueño de: " + this.listaMascota[i].getNombre() + " es: " + this.listaMascota[i].getDuenio().getNombre() + ", edad: " + this.listaMascota[i].getDuenio().getEdad());
            }
        }
    }
    public String isString() {
        String valor = null;
        boolean entradaValida = false;

        while (!entradaValida) {
            try {
                StdOut.println("Valor:");
                valor = StdIn.readString();
                entradaValida = true; // Establece entrada válida si no se lanza una excepción
            } catch (java.util.InputMismatchException e) {
                StdOut.println("El valor ingresado no es una cadena válida. Inténtelo de nuevo.");
            }
        }

        return valor;
    }

    public int isInt() {
        int valor = 0;
        boolean entradaValida = false;

        while (!entradaValida) {
            try {
                StdOut.println("Valor:");
                valor = StdIn.readInt();
                entradaValida = true; // Establece entrada válida si no se lanza una excepción
            } catch (java.util.InputMismatchException e) {
                StdOut.println("El valor ingresado no es un número entero válido. Inténtelo de nuevo.");
            }
        }

        return valor;
    }

}
